#! /bin/sh
$XGETTEXT *.cpp -o $podir/plasmamobileshellprivateplugin.pot
